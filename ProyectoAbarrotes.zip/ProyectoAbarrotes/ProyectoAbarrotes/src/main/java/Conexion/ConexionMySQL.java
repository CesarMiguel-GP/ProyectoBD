/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Conexion;

import Entrada.ProductoCompleto;
import Entrada.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConexionMySQL {
    
    public static Connection getConexion() {
        String puerto = "3306";
        String nombreBD = "abarrotes_la_soledad";
        String usuario = "root";
        String password = "1234";

        String URL = "jdbc:mysql://localhost:" + puerto + "/" + nombreBD + "?useSSL=false&serverTimezone=UTC";

        try {
            return DriverManager.getConnection(URL, usuario, password);
        } catch (SQLException e) {
            System.out.println("❌ Error al conectar a la base de datos:");
            System.out.println("Mensaje: " + e.getMessage());
            return null;
        }
    }
    
    
    
    
     // --------------------- Productos ----------------------------

    public static void crearTablaProductosSiNoExiste() {
    String sql = "CREATE TABLE IF NOT EXISTS productos (" +
                 "id_producto VARCHAR(10) PRIMARY KEY, " +
                 "nombre VARCHAR(100), " +
                 "precio DOUBLE, " +
                 "stock INT, " +
                 "id_proveedor VARCHAR(10), " +
                 "tipo VARCHAR(100), " +
                 "descripcion VARCHAR(255), " +
                 "url VARCHAR(255))";
    try (Connection conn = ConexionMySQL.getConexion(); Statement stmt = conn.createStatement()) {
        stmt.executeUpdate(sql);
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
    public static List<ProductoCompleto> obtenerProductos() {
    List<ProductoCompleto> lista = new ArrayList<>();
    String sql = "SELECT * FROM productos";
    try (Connection conn = ConexionMySQL.getConexion(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
        while (rs.next()) {
            ProductoCompleto p = new ProductoCompleto(
                rs.getString("id_producto"),
                rs.getString("nombre"),
                rs.getString("tipo"),
                rs.getDouble("precio"),
                rs.getString("url"),
                rs.getInt("stock"),
                rs.getString("id_proveedor")
            );
            lista.add(p);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return lista;
}

public static boolean insertarProducto(ProductoCompleto producto) {
    String sql = "INSERT INTO productos (nombre, precio, stock, id_proveedor, tipo, url) VALUES (?, ?, ?, ?, ?, ?)";
    try (Connection conn = ConexionMySQL.getConexion(); 
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        stmt.setString(1, producto.getNombre());
        stmt.setDouble(2, producto.getPrecio());
        stmt.setInt(3, producto.getStock());
        stmt.setString(4, producto.getIdProveedor());
        stmt.setString(5, producto.getTipo());
        stmt.setString(6, producto.getUrl());
        
        int filas = stmt.executeUpdate();
        return filas > 0;
    } catch (SQLException e) {
        System.out.println("Error al insertar producto:");
        e.printStackTrace();
        return false;
    }
}

    public static boolean hayStockSuficiente(String idProducto, int cantidadDeseada) {
    String sql = "SELECT stock FROM productos WHERE id_producto=?";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, idProducto);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            int stock = rs.getInt("stock");
            return stock >= cantidadDeseada;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
}

    public static void descontarStock(String idProducto, int cantidad) {
    String sql = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, cantidad);
        stmt.setString(2, idProducto);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public static void actualizarStock(String idProducto, int nuevoStock) {
    String sql = "UPDATE productos SET stock = ? WHERE id_producto = ?";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, nuevoStock);
        stmt.setString(2, idProducto);
        stmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error al actualizar el stock: " + e.getMessage());
    }
}
   
    public static void insertarProductosIniciales(List<ProductoCompleto> productos) {
    String sql = "INSERT INTO productos (id_producto, nombre, precio, stock, id_proveedor, tipo, url) VALUES (?, ?, ?, ?, ?, ?, ?)";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        for (ProductoCompleto p : productos) {
            stmt.setString(1, p.getIdProducto());
            stmt.setString(2, p.getNombre());
            stmt.setDouble(3, p.getPrecio());
            stmt.setInt(4, p.getStock());
            stmt.setString(5, p.getIdProveedor());
            stmt.setString(6, p.getTipo());
            stmt.setString(7, p.getUrl());
            stmt.executeUpdate();
        }
        System.out.println("Productos insertados correctamente.");
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
    public static List<ProductoCompleto> getListaProductos() {
    List<ProductoCompleto> lista = new ArrayList<>();

    lista.add(new ProductoCompleto("1", "Arroz 1kg", "Abarrotes Básicos", 25, "/Entrada/Imagenes/Arroz 1kg.jpg", 1234, "14"));
    lista.add(new ProductoCompleto("2", "Frijoles refritos negros", "Abarrotes Básicos", 35, "/Entrada/Imagenes/Frijoles refritos negros.jpg", 36547, "14"));
    lista.add(new ProductoCompleto("3", "Azúcar 1kg", "Abarrotes Básicos", 28, "/Entrada/Imagenes/Azúcar.jpg", 369, "1"));
    lista.add(new ProductoCompleto("4", "Conchitas Bimbo", "Pan y Galletas", 20, "/Entrada/Imagenes/Conchas.jpg", 1050, "13"));
    lista.add(new ProductoCompleto("5", "Gerber", "Bebés y Maternidad", 17, "/Entrada/Imagenes/Gerber.jpg", 75, "12"));
    lista.add(new ProductoCompleto("6", "Pañales", "Bebés y Maternidad", 380, "/Entrada/Imagenes/Pañales.jpg", 758, "7"));
    lista.add(new ProductoCompleto("7", "Toallitas húmedas Johnson’s Baby", "Bebés y Maternidad", 25, "/Entrada/Imagenes/Toallitas jonhson.jpg", 58465, "7"));
    lista.add(new ProductoCompleto("8", "Papalote de Tamarindo con chile 50g", "Dulcería y Snacks", 12, "/Entrada/Imagenes/Papalotes chile.jpg", 3469589, "4"));
    lista.add(new ProductoCompleto("9", "Galletas Oreo mini 90g", "Dulcería y Snacks", 25, "/Entrada/Imagenes/Oreo.jpg", 984712, "5"));
    lista.add(new ProductoCompleto("10", "Botana Takis Fuego 100g", "Dulcería y Snacks", 18, "/Entrada/Imagenes/Takis.jpg", 9841, "14"));
    lista.add(new ProductoCompleto("11", "Paleta Payaso 40g", "Dulcería y Snacks", 20, "/Entrada/Imagenes/Paleta payaso.jpg", 9852, "14"));
    lista.add(new ProductoCompleto("12", "Shampoo Savilé Sábila 750ml", "Limpieza e Higiene", 35, "/Entrada/Imagenes/Savilé.jpg", 750, "9"));
    lista.add(new ProductoCompleto("13", "Papel Higiénico Suavel 4 rollos", "Limpieza e Higiene", 50, "/Entrada/Imagenes/Papel suavel.jpg", 289, "7"));
    lista.add(new ProductoCompleto("14", "Jabón de tocador Zest 150g", "Limpieza e Higiene", 21, "/Entrada/Imagenes/Zest.jpg", 963, "9"));
    lista.add(new ProductoCompleto("15", "Detergente líquido Ariel Revitacolor 1L", "Limpieza e Higiene", 98, "/Entrada/Imagenes/Ariel.jpg", 852963, "6"));
    lista.add(new ProductoCompleto("16", "Leche Lala entera 1L", "Productos Perecederos", 22, "/Entrada/Imagenes/Leche lala.jpg", 695841, "6"));
    lista.add(new ProductoCompleto("17", "Huevos San Juan blanco 12 piezas", "Productos Perecederos", 45, "/Entrada/Imagenes/Huevos.jpg", 145, "2"));
    lista.add(new ProductoCompleto("18", "Queso panela Los Volcanes 250g", "Productos Perecederos", 50, "/Entrada/Imagenes/Queso panela volcanes.jpg", 3684, "4"));
    lista.add(new ProductoCompleto("19", "Croquetas Pedigree adulto 1kg", "Mascotas", 90, "/Entrada/Imagenes/Croquetas pedigree.jpg", 963, "8"));
    lista.add(new ProductoCompleto("20", "Arena para gato Michicat 5L", "Mascotas", 100, "/Entrada/Imagenes/Arena para gatos.jpg", 5459, "2"));
    lista.add(new ProductoCompleto("21", "Jeinga 5ml", "Bebés y Maternidad", 11, "/Entrada/Imagenes/21.jpg", 466, "10"));
    lista.add(new ProductoCompleto("22", "Carne molida res", "Productos Perecederos", 121, "/Entrada/Imagenes/22.jpg", 124, "13"));
    lista.add(new ProductoCompleto("23", "Limpiador para baño", "Limpieza e Higiene", 40, "/Entrada/Imagenes/23.jpg", 121, "4"));
    lista.add(new ProductoCompleto("24", "Jarabe para la tos", "Otros / Farmacia básica", 122, "/Entrada/Imagenes/24.jpg", 237, "14"));
    lista.add(new ProductoCompleto("25", "Refresco de manzana 2L", "Bebidas", 16, "/Entrada/Imagenes/25.jpg", 109, "8"));
    lista.add(new ProductoCompleto("26", "Chicharrones de harina", "Abarrotes Básicos", 47, "/Entrada/Imagenes/26.jpg", 25, "3"));
    lista.add(new ProductoCompleto("27", "Croquetas premium", "Mascotas", 149, "/Entrada/Imagenes/27.jpg", 396, "3"));
    lista.add(new ProductoCompleto("28", "Pan integral rebanado", "Pan y Galletas", 31, "/Entrada/Imagenes/28.jpg", 241, "4"));
    lista.add(new ProductoCompleto("29", "Cepillo doble cara", "Mascotas", 45, "/Entrada/Imagenes/29.jpg", 252, "6"));
    lista.add(new ProductoCompleto("30", "Jugo de manzana", "Bebidas", 79, "/Entrada/Imagenes/30.jpg", 249, "4"));
    lista.add(new ProductoCompleto("31", "Sopa de pasta codito", "Abarrotes Básicos", 136, "/Entrada/Imagenes/31.jpg", 343, "1"));
    lista.add(new ProductoCompleto("32", "Premios de salmón", "Abarrotes Básicos", 78, "/Entrada/Imagenes/32.jpg", 241, "5"));
    lista.add(new ProductoCompleto("33", "Toallas húmedas para superficies", "Limpieza e Higiene", 120, "/Entrada/Imagenes/33.jpeg", 217, "3"));
    lista.add(new ProductoCompleto("34", "Jabón en barra", "Limpieza e Higiene", 103, "/Entrada/Imagenes/34.jpg", 103, "7"));
    lista.add(new ProductoCompleto("35", "Pastillas para alergia", "Otros / Farmacia básica", 40, "/Entrada/Imagenes/35.jpg", 352, "1"));
    lista.add(new ProductoCompleto("36", "Biberón anticólicos", "Bebés y Maternidad", 57, "/Entrada/Imagenes/36.jpg", 217, "1"));
    lista.add(new ProductoCompleto("37", "Palanquetas de amaranto", "Dulcería y Snacks", 133, "/Entrada/Imagenes/37.jpg", 319, "12"));
    lista.add(new ProductoCompleto("38", "Pasta dental infantil", "Limpieza e Higiene", 136, "/Entrada/Imagenes/38.jpg", 309, "12"));
    lista.add(new ProductoCompleto("39", "Bebida láctea sabor chocolate", "Bebidas", 80, "/Entrada/Imagenes/39.jpg", 382, "14"));
    lista.add(new ProductoCompleto("40", "Bloqueador solar bebé", "Abarrotes Básicos", 85, "/Entrada/Imagenes/40.jpg", 336, "12"));
    lista.add(new ProductoCompleto("41", "Pan pita", "Pan y Galletas", 136, "/Entrada/Imagenes/41.jpg", 335, "4"));
    lista.add(new ProductoCompleto("42", "Tortillas de maíz", "Productos Perecederos", 33, "/Entrada/Imagenes/42.jpg", 168, "14"));
    lista.add(new ProductoCompleto("43", "Bolsa de arena ecológica", "Mascotas", 14, "/Entrada/Imagenes/43.jpg", 185, "12"));
    lista.add(new ProductoCompleto("44", "Botana mixta", "Dulcería y Snacks", 37, "/Entrada/Imagenes/44.jpg", 338, "14"));
    lista.add(new ProductoCompleto("45", "Desodorante ambiental", "Limpieza e Higiene", 126, "/Entrada/Imagenes/45.jpg", 388, "9"));
    lista.add(new ProductoCompleto("46", "Dispensador de comida", "Abarrotes Básicos", 21, "/Entrada/Imagenes/46.jpg", 274, "5"));
    lista.add(new ProductoCompleto("47", "Panela fresca", "Pan y Galletas", 111, "/Entrada/Imagenes/47.jpeg", 301, "9"));
    lista.add(new ProductoCompleto("48", "Aceite de canola 900ml", "Abarrotes Básicos", 18, "/Entrada/Imagenes/48.jpg", 290, "10"));
    lista.add(new ProductoCompleto("49", "Toallas antisépticas", "Abarrotes Básicos", 127, "/Entrada/Imagenes/49.jpg", 57, "1"));
    lista.add(new ProductoCompleto("50", "Collar ajustable para gato", "Mascotas", 115, "/Entrada/Imagenes/50.jpeg", 166, "2"));
    lista.add(new ProductoCompleto("51", "Naranjas jugosas", "Productos Perecederos", 117, "/Entrada/Imagenes/51.jpg", 300, "1"));
    lista.add(new ProductoCompleto("52", "Gomitas con azúcar", "Dulcería y Snacks", 92, "/Entrada/Imagenes/52.jpg", 143, "14"));
    lista.add(new ProductoCompleto("53", "Leche etapa 2", "Bebés y Maternidad", 47, "/Entrada/Imagenes/53.jpg", 308, "3"));
    lista.add(new ProductoCompleto("54", "Pomada cicatrizante", "Otros / Farmacia básica", 117, "/Entrada/Imagenes/54.jpeg", 346, "11"));
    lista.add(new ProductoCompleto("55", "Crema entera", "Productos Perecederos", 123, "/Entrada/Imagenes/55.jpg", 273, "7"));
    lista.add(new ProductoCompleto("56", "Azúcar morena", "Abarrotes Básicos", 22, "/Entrada/Imagenes/56.jpg", 187, "4"));
    lista.add(new ProductoCompleto("57", "Suero oral", "Otros / Farmacia básica", 49, "/Entrada/Imagenes/57.jpeg", 204, "14"));
    lista.add(new ProductoCompleto("58", "Gasas estériles", "Otros / Farmacia básica", 32, "/Entrada/Imagenes/58.jpg", 118, "9"));
    lista.add(new ProductoCompleto("59", "Pelota con sonido", "Mascotas", 88, "/Entrada/Imagenes/59.jpg", 394, "14"));
    lista.add(new ProductoCompleto("60", "Frijoles negros 1kg", "Abarrotes Básicos", 55, "/Entrada/Imagenes/60.jpg", 37, "11"));
    lista.add(new ProductoCompleto("61", "Sal refinada", "Abarrotes Básicos", 100, "/Entrada/Imagenes/61.jpeg", 180, "3"));
    lista.add(new ProductoCompleto("62", "Croissants", "Pan y Galletas", 11, "/Entrada/Imagenes/62.jpeg", 217, "12"));
    lista.add(new ProductoCompleto("63", "Cucharita suave", "Bebés y Maternidad", 65, "/Entrada/Imagenes/63.jpeg", 233, "2"));
    lista.add(new ProductoCompleto("64", "Crema para bebé", "Bebés y Maternidad", 74, "/Entrada/Imagenes/64.jpeg", 91, "4"));
    lista.add(new ProductoCompleto("65", "Trapeador de microfibra", "Limpieza e Higiene", 123, "/Entrada/Imagenes/65.jpeg", 160, "5"));
    lista.add(new ProductoCompleto("66", "Consomé en polvo", "Abarrotes Básicos", 95, "/Entrada/Imagenes/66.jpg", 164, "13"));
    lista.add(new ProductoCompleto("67", "Agua saborizada", "Bebidas", 83, "/Entrada/Imagenes/67.jpeg", 308, "3"));
    lista.add(new ProductoCompleto("68", "Queso Oaxaca", "Productos Perecederos", 150, "/Entrada/Imagenes/68.jpg", 42, "14"));
    lista.add(new ProductoCompleto("69", "Galletas saladas", "Pan y Galletas", 98, "/Entrada/Imagenes/69.jpg", 63, "14"));
    lista.add(new ProductoCompleto("70", "Pan de ajo", "Pan y Galletas", 18, "/Entrada/Imagenes/70.jpg", 175, "3"));
    lista.add(new ProductoCompleto("71", "Caja de curitas", "Otros / Farmacia básica", 148, "/Entrada/Imagenes/71.jpg", 202, "6"));
    lista.add(new ProductoCompleto("72", "Galletas integrales", "Pan y Galletas", 30, "/Entrada/Imagenes/72.jpg", 353, "4"));
    lista.add(new ProductoCompleto("73", "Termómetro infrarrojo", "Otros / Farmacia básica", 84, "/Entrada/Imagenes/73.jpg", 357, "3"));
    lista.add(new ProductoCompleto("74", "Pan dulce surtido", "Pan y Galletas", 114, "/Entrada/Imagenes/74.jpg", 211, "2"));
    lista.add(new ProductoCompleto("75", "Vinagre blanco", "Abarrotes Básicos", 70, "/Entrada/Imagenes/75.jpg", 188, "14"));
    lista.add(new ProductoCompleto("76", "Arroz integral 1kg", "Abarrotes Básicos", 17, "/Entrada/Imagenes/76.jpg", 18, "5"));
    lista.add(new ProductoCompleto("77", "Manzanas verdes", "Productos Perecederos", 122, "/Entrada/Imagenes/77.jpeg", 206, "6"));
    lista.add(new ProductoCompleto("78", "Arenero chico", "Mascotas", 124, "/Entrada/Imagenes/78.jpg", 336, "6"));
    lista.add(new ProductoCompleto("79", "Aceite para bebé", "Bebés y Maternidad", 25, "/Entrada/Imagenes/79.jpg", 54, "9"));
    lista.add(new ProductoCompleto("80", "Pan molido", "Pan y Galletas", 149, "/Entrada/Imagenes/80.jpg", 159, "1"));
    lista.add(new ProductoCompleto("81", "Caramelos masticables", "Dulcería y Snacks", 106, "/Entrada/Imagenes/81.jpg", 208, "10"));
    lista.add(new ProductoCompleto("82", "Paracetamol gotas", "Otros / Farmacia básica", 59, "/Entrada/Imagenes/82.jpg", 300, "2"));
    lista.add(new ProductoCompleto("83", "Talco para bebé", "Bebés y Maternidad", 83, "/Entrada/Imagenes/83.avif", 106, "12"));
    lista.add(new ProductoCompleto("84", "Mantequilla sin sal", "Abarrotes Básicos", 112, "/Entrada/Imagenes/84.jpg", 15, "8"));
    lista.add(new ProductoCompleto("85", "Chocolates mini", "Dulcería y Snacks", 13, "/Entrada/Imagenes/85.jpg", 316, "10"));
    lista.add(new ProductoCompleto("86", "Ibuprofeno 400mg", "Otros / Farmacia básica", 16, "/Entrada/Imagenes/86.jpg", 196, "6"));
    lista.add(new ProductoCompleto("87", "Pan de caja blanco", "Pan y Galletas", 139, "/Entrada/Imagenes/87.jpg", 16, "12"));
    lista.add(new ProductoCompleto("88", "Néctar de durazno", "Bebidas", 34, "/Entrada/Imagenes/88.jpg", 136, "6"));
    lista.add(new ProductoCompleto("89", "Juguete para bebé", "Bebés y Maternidad", 69, "/Entrada/Imagenes/89.jpg", 246, "5"));
    lista.add(new ProductoCompleto("90", "Papel higiénico jumbo", "Limpieza e Higiene", 10, "/Entrada/Imagenes/90.jpg", 103, "10"));
    lista.add(new ProductoCompleto("91", "Barritas de cereal", "Dulcería y Snacks", 54, "/Entrada/Imagenes/91.jpg", 63, "1"));
    lista.add(new ProductoCompleto("92", "Té verde en bolsitas", "Bebidas", 131, "/Entrada/Imagenes/92.jpg", 149, "10"));
    lista.add(new ProductoCompleto("93", "Agua embotellada 1L", "Bebidas", 68, "/Entrada/Imagenes/93.jpg", 176, "12"));
    lista.add(new ProductoCompleto("94", "Huevo orgánico 12 pzas", "Productos Perecederos", 111, "/Entrada/Imagenes/94.jpg", 77, "1"));
    lista.add(new ProductoCompleto("95", "Palanquetas de cacahuate", "Dulcería y Snacks", 13, "/Entrada/Imagenes/95.jpeg", 100, "13"));
    lista.add(new ProductoCompleto("96", "Refresco de toronja", "Bebidas", 96, "/Entrada/Imagenes/96.jpg", 66, "14"));
    lista.add(new ProductoCompleto("97", "Cloro 2L", "Limpieza e Higiene", 73, "/Entrada/Imagenes/97.jpg", 360, "8"));
    lista.add(new ProductoCompleto("98", "Galletas de chocolate", "Pan y Galletas", 147, "/Entrada/Imagenes/98.jpg", 283, "3"));
    lista.add(new ProductoCompleto("99", "Limpiador desinfectante", "Limpieza e Higiene", 58, "/Entrada/Imagenes/99.avif", 325, "6"));
    lista.add(new ProductoCompleto("100", "Pechuga de pollo", "Productos Perecederos", 19, "/Entrada/Imagenes/100.jpg", 389, "5"));
    return lista;
}
    public static ProductoCompleto buscarProductoPorID(String idProducto) {
    String sql = "SELECT * FROM productos WHERE id_producto = ?";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, idProducto);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return new ProductoCompleto(
                rs.getString("id_producto"),
                rs.getString("nombre"),
                rs.getString("tipo"),
                rs.getDouble("precio"),
                rs.getString("url"),
                rs.getInt("stock"),
                rs.getString("id_proveedor")
            );
        }
    } catch (SQLException e) {
        System.out.println("Error al buscar el producto con ID: " + idProducto);
        e.printStackTrace();
    }
    return null;
}

public static int obtenerStock(String idProducto) {
    String sql = "SELECT stock FROM productos WHERE id_producto = ?";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, idProducto);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getInt("stock");
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener el stock del producto con ID: " + idProducto);
        e.printStackTrace();
    }
    return -1;
}
    public static ProductoCompleto buscarProductoPorNombre(String nombreBuscado) {
    String sql = "SELECT * FROM productos WHERE nombre = ?";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, nombreBuscado);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return new ProductoCompleto(
                rs.getString("id_producto"),
                rs.getString("nombre"),
                rs.getString("tipo"),
                rs.getDouble("precio"),
                rs.getString("url"),
                rs.getInt("stock"),
                rs.getString("id_proveedor")
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

    
    // -------------------- Usuarios ------------------------

    public static void crearTablaUsuariosSiNoExiste() {
    String sql = "CREATE TABLE IF NOT EXISTS usuarios (" +
                 "id INT AUTO_INCREMENT PRIMARY KEY, " +
                 "nombre VARCHAR(100), " +
                 "correo VARCHAR(100), " +
                 "telefono VARCHAR(20), " +
                 "rol VARCHAR(20), " +
                 "usuario VARCHAR(50), " +
                 "contraseña VARCHAR(100))";
    try (Connection conn = ConexionMySQL.getConexion(); Statement stmt = conn.createStatement()) {
        stmt.executeUpdate(sql);
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    
    public static boolean insertarEnAdministrador(Usuario u) {
    String sql = "INSERT INTO administrador (nombre, correo, apellido_paterno, apellido_materno, fecha_nacimiento, genero, contraseña) VALUES (?, ?, ?, ?, ?, ?, ?)";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, u.getNombre());
        stmt.setString(2, u.getCorreo());
        stmt.setString(3, u.getAPaterno());
        stmt.setString(4, u.getAMaterno());
        stmt.setDate(5, new java.sql.Date(u.getFechaN().getTime()));
        stmt.setString(6, u.getGenero());
        stmt.setString(7, u.getContrase());
        return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
        System.out.println("❌ Error al insertar en administrador: " + e.getMessage());
        return false;
    }
}
    
    public static boolean insertarEnClientes(Usuario u) {
    String sql = "INSERT INTO clientes (nombre, correo, apellido_paterno, apellido_materno, fecha_nacimiento, genero, contraseña) VALUES (?, ?, ?, ?, ?, ?, ?)";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, u.getNombre());
        stmt.setString(2, u.getCorreo());
        stmt.setString(3, u.getAPaterno());
        stmt.setString(4, u.getAMaterno());
        stmt.setDate(5, new java.sql.Date(u.getFechaN().getTime()));
        stmt.setString(6, u.getGenero());
        stmt.setString(7, u.getContrase());
        return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
        System.out.println("❌ Error al insertar en clientes: " + e.getMessage());
        return false;
    }
}
    
public static boolean insertarUsuario(String nombre, String usuario, String contrasena, String rol) {
    String sql = "INSERT INTO usuarios (nombre, usuario, contraseña, rol) VALUES (?, ?, ?, ?)";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, nombre);
        stmt.setString(2, usuario);
        stmt.setString(3, contrasena);
        stmt.setString(4, rol);
        return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
        System.out.println("Error al insertar usuario: " + e.getMessage());
        return false;
    }
}

public static boolean validarUsuario(String usuario, String contrasena) {
    String sql = "SELECT * FROM usuarios WHERE usuario = ? AND contraseña = ?";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, usuario);
        stmt.setString(2, contrasena);
        ResultSet rs = stmt.executeQuery();
        return rs.next();
    } catch (SQLException e) {
        System.out.println("Error al validar usuario: " + e.getMessage());
        return false;
    }
}

public static boolean insertarProveedor(String idProveedor, String nombre) {
    String sql = "INSERT INTO proveedores (id_proveedor, nombre) VALUES (?, ?)";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, idProveedor);
        stmt.setString(2, nombre);
        return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
        System.out.println("Error al insertar proveedor: " + e.getMessage());
        return false;
    }
}

public static boolean eliminarProducto(String idProducto) {
    String sql = "DELETE FROM productos WHERE id_producto = ?";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, idProducto);
        return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
        System.out.println("Error al eliminar producto: " + e.getMessage());
        return false;
    }
}

public static void buscarTabla(String nombreTabla) {
    String sql = "SELECT * FROM " + nombreTabla;
    try (Connection conn = ConexionMySQL.getConexion(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
        boolean hayResultados = false;
        while (rs.next()) {
            hayResultados = true;
            int columnas = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= columnas; i++) {
                String nombreCol = rs.getMetaData().getColumnName(i);
                String dato = rs.getString(i);
                System.out.print(nombreCol + ": " + dato + " | ");
            }
            System.out.println();
        }
        if (!hayResultados) {
            System.out.println("La tabla está vacía.");
        }
    } catch (SQLException e) {
        System.out.println("No se pudo consultar la tabla '" + nombreTabla + "'. Verifica que exista. Detalles: " + e.getMessage());
    }
}

public static void buscarRegistro(String nombreTabla, String columna, String valor) {
    String sql = "SELECT * FROM " + nombreTabla + " WHERE " + columna + " = '" + valor + "'";
    try (Connection conn = ConexionMySQL.getConexion(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
        boolean encontrado = false;
        while (rs.next()) {
            encontrado = true;
            int columnas = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= columnas; i++) {
                String nombre = rs.getMetaData().getColumnName(i);
                String dato = rs.getString(i);
                System.out.println(nombre + ": " + dato);
            }
            System.out.println("--------------------");
        }
        if (!encontrado) {
            System.out.println("No se encontró ningún registro.");
        }
    } catch (SQLException e) {
        System.out.println("Error al buscar en '" + nombreTabla + "'. Detalles: " + e.getMessage());
    }
}

public static boolean insertarUsuario(Usuario u) {
    String sql = "INSERT INTO clientes (nombre, correo, apellido_paterno, apellido_materno, fecha_nacimiento, genero, contraseña) VALUES (?, ?, ?, ?, ?, ?, ?)";
    try (Connection conn = ConexionMySQL.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, u.getNombre());
        stmt.setString(2, u.getCorreo());
        stmt.setString(3, u.getAPaterno());
        stmt.setString(4, u.getAMaterno());
        stmt.setDate(5, new java.sql.Date(u.getFechaN().getTime()));
        stmt.setString(6, u.getGenero());
        stmt.setString(7, u.getContrase());
        int filas = stmt.executeUpdate();
        return filas > 0;
    } catch (SQLException e) {
        System.out.println("Error al insertar usuario: " + e.getMessage());
        return false;
    }
}

public static boolean registrarDetalleVenta(int idVenta, String idProducto, int cantidad, double precio) {
    String sql = "INSERT INTO detalle_venta(id_venta, id_producto, cantidad, precio_unitario, importe) VALUES (?, ?, ?, ?, ?)";

    try (Connection conn = ConexionMySQL.getConexion();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, idVenta);
        ps.setString(2, idProducto);
        ps.setInt(3, cantidad);
        ps.setDouble(4, precio);
        ps.setDouble(5, precio * cantidad);

        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
}