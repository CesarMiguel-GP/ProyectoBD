package Correo;

import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.activation.*;
import javax.mail.*;
import javax.mail.internet.*;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.Random;

public class EnvioCorreo {
    private static final Logger LOGGER = Logger.getLogger(EnvioCorreo.class.getName());
    private static final ExecutorService executor = Executors.newFixedThreadPool(3);
    private static final Random random = new Random();
    // Configuración mejorada con pool de conexiones
    private static Session crearSesion() {
        final String remitente = "lasoledad0abarrotes@gmail.com";
        final String clave = "agdllumtmtvdhwcd";

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.starttls.required", "true");
        
        // Solución para problemas de certificados SSL
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2 TLSv1.3");
        props.put("mail.smtp.ssl.checkserveridentity", "false");
        
        // Pool de conexiones
        props.put("mail.smtp.connectionpoolsize", "10");
        props.put("mail.smtp.connectionpooltimeout", "30000");

        return Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, clave);
            }
        });
    }

    // Versión síncrona mejorada
    public static boolean enviarCorreoConPDF(String destinatario, String rutaArchivo) {
        try {
            // Validaciones rápidas
            if (destinatario == null || destinatario.trim().isEmpty()) {
                LOGGER.log(Level.WARNING, "Destinatario vacío");
                return false;
            }
            
            if (rutaArchivo != null && !new File(rutaArchivo).exists()) {
                LOGGER.log(Level.WARNING, "Archivo PDF no encontrado: " + rutaArchivo);
                return false;
            }

            Session sesion = crearSesion();
            Message mensaje = construirMensaje(sesion, destinatario, rutaArchivo);
            
            Transport.send(mensaje);
            LOGGER.log(Level.INFO, "Correo enviado exitosamente a: " + destinatario);
            return true;
            
        } catch (MessagingException e) {
            LOGGER.log(Level.SEVERE, "Error enviando correo a " + destinatario, e);
            return false;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error inesperado", e);
            return false;
        }
    }

    // Versión asíncrona para mayor velocidad
    public static CompletableFuture<Boolean> enviarCorreoAsync(String destinatario, String rutaArchivo) {
        return CompletableFuture.supplyAsync(() -> {
            return enviarCorreoConPDF(destinatario, rutaArchivo);
        }, executor);
    }

    private static Message construirMensaje(Session sesion, String destinatario, String rutaArchivo) 
            throws MessagingException, UnsupportedEncodingException {
        Message mensaje = new MimeMessage(sesion);
        mensaje.setFrom(new InternetAddress("lasoledad0abarrotes@gmail.com", "Abarrotes La Soledad"));
        mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
        mensaje.setSubject("¡Bienvenido a Abarrotes La Soledad!");

        if (rutaArchivo != null && new File(rutaArchivo).exists()) {
            // Con adjunto
            Multipart multipart = new MimeMultipart();
            
            // Cuerpo del mensaje HTML
            BodyPart cuerpoMensaje = new MimeBodyPart();
            String contenidoHTML = """
                <html>
                <body style="font-family: Arial, sans-serif; color: #333;">
                    <h2 style="color: #2c5aa0;">¡Bienvenido a Abarrotes La Soledad!</h2>
                    <p>Gracias por registrarte en nuestro sistema.</p>
                    <p>Adjunto encontrarás tu documento de bienvenida.</p>
                    <p style="color: #666;">¡Esperamos verte pronto!</p>
                    <hr>
                    <small>Abarrotes La Soledad - Tu tienda de confianza</small>
                </body>
                </html>
                """;
            cuerpoMensaje.setContent(contenidoHTML, "text/html; charset=utf-8");
            multipart.addBodyPart(cuerpoMensaje);

            // Adjunto optimizado
            try {
                MimeBodyPart adjunto = new MimeBodyPart();
                DataSource fuente = new FileDataSource(rutaArchivo);
                adjunto.setDataHandler(new DataHandler(fuente));
                adjunto.setFileName("Bienvenida_AbarrotesLaSoledad.pdf");
                multipart.addBodyPart(adjunto);
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Error adjuntando archivo: " + e.getMessage());
            }

            mensaje.setContent(multipart);
        } else {
            // Solo texto sin adjunto
            mensaje.setContent(
                "Bienvenido al sistema de Abarrotes La Soledad\n\n¡Gracias por registrarte!", 
                "text/plain; charset=utf-8"
            );
        }
        
        return mensaje;
    }
    public static boolean enviarTicketPorCorreo(String destinatario, String rutaArchivo) {
        try {
            if (destinatario == null || destinatario.trim().isEmpty()) {
                LOGGER.log(Level.WARNING, "Destinatario vacío");
                return false;
            }

            if (rutaArchivo != null && !new File(rutaArchivo).exists()) {
                LOGGER.log(Level.WARNING, "Archivo PDF no encontrado: " + rutaArchivo);
                return false;
            }

            Session sesion = crearSesion();
            Message mensaje = new MimeMessage(sesion);
            mensaje.setFrom(new InternetAddress("lasoledad0abarrotes@gmail.com", "Abarrotes La Soledad"));
            mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            mensaje.setSubject("Tu ticket de compra - Abarrotes La Soledad");

            Multipart multipart = new MimeMultipart();

            // Cuerpo del mensaje para ticket
            BodyPart cuerpoMensaje = new MimeBodyPart();
            String contenidoHTML = """
                <html>
                <body style="font-family: Arial, sans-serif; color: #333;">
                    <h2 style="color: #2c5aa0;">¡Gracias por tu compra!</h2>
                    <p>Tu compra en Abarrotes La Soledad ha sido procesada exitosamente.</p>
                    <p>Adjunto encontrarás tu ticket de compra en formato PDF.</p>
                    <p style="color: #666;">¡Esperamos verte pronto otra vez!</p>
                    <hr>
                    <small>Abarrotes La Soledad - Tu tienda de confianza</small>
                </body>
                </html>
                """;
            cuerpoMensaje.setContent(contenidoHTML, "text/html; charset=utf-8");
            multipart.addBodyPart(cuerpoMensaje);

            // Adjunto
            MimeBodyPart adjunto = new MimeBodyPart();
            DataSource fuente = new FileDataSource(rutaArchivo);
            adjunto.setDataHandler(new DataHandler(fuente));
            adjunto.setFileName("Ticket_Compra_AbarrotesLaSoledad.pdf");
            multipart.addBodyPart(adjunto);

            mensaje.setContent(multipart);
            Transport.send(mensaje);

            LOGGER.log(Level.INFO, "Ticket enviado exitosamente a: " + destinatario);
            return true;

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error enviando ticket a " + destinatario, e);
            return false;
        }
    }
    // Método para cerrar el pool de hilos
    public static void shutdown() {
        executor.shutdown();
    }
}