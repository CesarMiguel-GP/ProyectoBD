package Correo;

import Entrada.Usuario;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.nio.file.Files; 
import java.nio.file.Paths;

public class GeneradorPDF {
    private static final Logger LOGGER = Logger.getLogger(GeneradorPDF.class.getName());
    private static final SimpleDateFormat FORMATO_FECHA = new SimpleDateFormat("dd/MM/yyyy");
    
    // Fuentes pre-configuradas para mejor rendimiento
    private static Font tituloFont;
    private static Font subtituloFont;
    private static Font textoFont;
    private static Font textoDestacado;
    
    static {
        try {
            tituloFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
            subtituloFont = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.BLUE);
            textoFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL);
            textoDestacado = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error inicializando fuentes", e);
        }
    }

    public static boolean generarTicketPDF(Usuario usuario, String rutaSalida) {
        if (usuario == null) {
            System.out.println("Usuario no puede ser nulo");
            return false;
        }
        
        if (rutaSalida == null || rutaSalida.trim().isEmpty()) {
            System.out.println("Ruta de salida no válida");
            return false;
        }

        // Crear directorio si no existe
        try {
            Files.createDirectories(Paths.get(rutaSalida).getParent());
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "No se pudo crear directorio", e);
        }

        Document documento = new Document(PageSize.A4);
        PdfWriter writer = null;
        
        try {
            writer = PdfWriter.getInstance(documento, new FileOutputStream(rutaSalida));
            writer.setCompressionLevel(9); // Máxima compresión para archivos más pequeños
            documento.open();

            // Header mejorado
            agregarHeader(documento);
            
            // Información del usuario
            agregarInformacionUsuario(documento, usuario);
            
            // Mensaje de bienvenida
            agregarMensajeBienvenida(documento, usuario);
            
            // Footer
            agregarFooter(documento);

            LOGGER.log(Level.INFO, "PDF generado exitosamente: " + rutaSalida);
            return true;
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error generando PDF: " + e.getMessage(), e);
            return false;
        } finally {
            if (documento.isOpen()) {
                documento.close();
            }
        }
    }

    private static void agregarHeader(Document documento) throws DocumentException {
        Paragraph titulo = new Paragraph("ABARROTES LA SOLEDAD", tituloFont);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(10f);
        documento.add(titulo);

        Paragraph subtitulo = new Paragraph("¡BIENVENIDO!", subtituloFont);
        subtitulo.setAlignment(Element.ALIGN_CENTER);
        subtitulo.setSpacingAfter(20f);
        documento.add(subtitulo);
        
        // Línea decorativa
        Paragraph linea = new Paragraph("═══════════════════════════════════════", textoFont);
        linea.setAlignment(Element.ALIGN_CENTER);
        linea.setSpacingAfter(15f);
        documento.add(linea);
    }

    private static void agregarInformacionUsuario(Document documento, Usuario usuario) throws DocumentException {
        documento.add(new Paragraph("INFORMACIÓN DEL USUARIO:", subtituloFont));
        documento.add(Chunk.NEWLINE);
        
        // Tabla para mejor organización
        PdfPTable tabla = new PdfPTable(2);
        tabla.setWidthPercentage(100);
        tabla.setSpacingBefore(10f);
        tabla.setSpacingAfter(15f);
        
        // Configurar tabla
        tabla.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        tabla.getDefaultCell().setPadding(5f);
        
        agregarFilaTabla(tabla, "Nombre completo:", 
            usuario.getNombre() + " " + usuario.getAPaterno() + " " + usuario.getAMaterno());
        agregarFilaTabla(tabla, "Correo electrónico:", usuario.getCorreo());
        agregarFilaTabla(tabla, "Género:", usuario.getGenero());
        agregarFilaTabla(tabla, "Fecha de nacimiento:", FORMATO_FECHA.format(usuario.getFechaN()));
        agregarFilaTabla(tabla, "Edad:", usuario.getEdad() + " años");
        
        documento.add(tabla);
    }
    
    private static void agregarFilaTabla(PdfPTable tabla, String etiqueta, String valor) {
        PdfPCell celdaEtiqueta = new PdfPCell(new Phrase(etiqueta, textoDestacado));
        celdaEtiqueta.setBorder(Rectangle.NO_BORDER);
        celdaEtiqueta.setPadding(5f);
        tabla.addCell(celdaEtiqueta);
        
        PdfPCell celdaValor = new PdfPCell(new Phrase(valor, textoFont));
        celdaValor.setBorder(Rectangle.NO_BORDER);
        celdaValor.setPadding(5f);
        tabla.addCell(celdaValor);
    }

    private static void agregarMensajeBienvenida(Document documento, Usuario usuario) throws DocumentException {
        Paragraph saludo = new Paragraph("¡Hola " + usuario.getNombre() + "!", textoDestacado);
        saludo.setSpacingBefore(15f);
        documento.add(saludo);

        String mensajeBienvenida = """
            Gracias por registrarte en Abarrotes La Soledad. Nos emociona tenerte como parte de nuestra familia.
            
            En nuestra tienda encontrarás:
            • Productos frescos y de calidad
            • Precios competitivos
            • Atención personalizada
            • Ofertas especiales para clientes registrados
            
            ¡Esperamos verte pronto en nuestras instalaciones y brindarte el mejor servicio!
            """;
            
        Paragraph mensaje = new Paragraph(mensajeBienvenida, textoFont);
        mensaje.setSpacingBefore(10f);
        mensaje.setAlignment(Element.ALIGN_JUSTIFIED);
        documento.add(mensaje);
    }

    private static void agregarFooter(Document documento) throws DocumentException {
        Paragraph footer = new Paragraph("\nAbarrotes La Soledad - Tu tienda de confianza", 
            new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY));
        footer.setAlignment(Element.ALIGN_CENTER);
        footer.setSpacingBefore(20f);
        documento.add(footer);
    }
}