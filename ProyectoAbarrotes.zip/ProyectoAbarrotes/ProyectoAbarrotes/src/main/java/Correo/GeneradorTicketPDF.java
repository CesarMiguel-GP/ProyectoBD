package Correo;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import Conexion.ConexionMySQL;
import Entrada.ProductoCompleto;

public class GeneradorTicketPDF {
    private static final Logger LOGGER = Logger.getLogger(GeneradorTicketPDF.class.getName());
    private static final SimpleDateFormat FORMATO_FECHA = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    
    // Fuentes para el ticket
    private static Font tituloFont;
    private static Font subtituloFont;
    private static Font textoFont;
    private static Font textoDestacado;
    private static Font textoMonospace;
    
    static {
        try {
            tituloFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.DARK_GRAY);
            subtituloFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLUE);
            textoFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);
            textoDestacado = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
            textoMonospace = new Font(Font.FontFamily.COURIER, 9, Font.NORMAL);
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error inicializando fuentes", e);
        }
    }

    public static boolean generarTicketCompraPDF(Map<String, Integer> carrito, double total, 
                                               String formaPago, String rutaSalida, String correoCliente) {
        if (carrito == null || carrito.isEmpty()) {
            System.out.println("El carrito está vacío");
            return false;
        }
        
        if (rutaSalida == null || rutaSalida.trim().isEmpty()) {
            System.out.println("Ruta de salida no válida");
            return false;
        }

        // Crear directorio si no existe
        try {
            Files.createDirectories(Paths.get(rutaSalida).getParent());
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "No se pudo crear directorio", e);
        }

        Document documento = new Document(PageSize.A4);
        PdfWriter writer = null;
        ConexionMySQL conexion = new ConexionMySQL();
        
        try {
            writer = PdfWriter.getInstance(documento, new FileOutputStream(rutaSalida));
            writer.setCompressionLevel(9);
            documento.open();

            // Header del ticket
            agregarHeaderTicket(documento);
            
            // Información de la compra
            agregarInformacionCompra(documento, carrito, total, formaPago, correoCliente, conexion);
            
            // Footer del ticket
            agregarFooterTicket(documento);

            LOGGER.log(Level.INFO, "Ticket PDF generado exitosamente: " + rutaSalida);
            return true;
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error generando ticket PDF: " + e.getMessage(), e);
            return false;
        } finally {
            if (documento.isOpen()) {
                documento.close();
            }
        }
    }

    private static void agregarHeaderTicket(Document documento) throws DocumentException {
        // Título principal
        Paragraph titulo = new Paragraph("🛒 ABARROTES LA SOLEDAD", tituloFont);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(5f);
        documento.add(titulo);

        // Subtítulo
        Paragraph subtitulo = new Paragraph("TICKET DE COMPRA", subtituloFont);
        subtitulo.setAlignment(Element.ALIGN_CENTER);
        subtitulo.setSpacingAfter(10f);
        documento.add(subtitulo);
        
        // Fecha y hora
        Paragraph fecha = new Paragraph("📅 Fecha: " + FORMATO_FECHA.format(new Date()), textoFont);
        fecha.setAlignment(Element.ALIGN_CENTER);
        fecha.setSpacingAfter(15f);
        documento.add(fecha);
        
        // Línea separadora
        Paragraph linea = new Paragraph("═══════════════════════════════════════", textoFont);
        linea.setAlignment(Element.ALIGN_CENTER);
        linea.setSpacingAfter(10f);
        documento.add(linea);
    }

    private static void agregarInformacionCompra(Document documento, Map<String, Integer> carrito, 
                                               double total, String formaPago, String correoCliente, 
                                               ConexionMySQL conexion) throws DocumentException {
        
        // Información del cliente si se proporciona
        if (correoCliente != null && !correoCliente.trim().isEmpty()) {
            Paragraph cliente = new Paragraph("Cliente: " + correoCliente, textoDestacado);
            cliente.setSpacingBefore(5f);
            cliente.setSpacingAfter(10f);
            documento.add(cliente);
        }

        // Crear tabla de productos
        PdfPTable tabla = new PdfPTable(4);
        tabla.setWidthPercentage(100);
        tabla.setSpacingBefore(10f);
        tabla.setSpacingAfter(15f);
        
        // Configurar anchos de columnas
        float[] anchosColumnas = {40f, 15f, 20f, 25f};
        tabla.setWidths(anchosColumnas);
        
        // Headers de la tabla
        agregarHeaderTabla(tabla, "Producto", textoDestacado);
        agregarHeaderTabla(tabla, "Cant.", textoDestacado);
        agregarHeaderTabla(tabla, "Precio", textoDestacado);
        agregarHeaderTabla(tabla, "Subtotal", textoDestacado);
        
        // Agregar productos del carrito
        for (String idProducto : carrito.keySet()) {
            ProductoCompleto producto = conexion.buscarProductoPorID(idProducto);
            if (producto != null) {
                int cantidad = carrito.get(idProducto);
                double precio = producto.getPrecio();
                double subtotal = cantidad * precio;
                
                agregarFilaProducto(tabla, producto.getNombre(), 
                                  String.valueOf(cantidad),
                                  String.format("$%.2f", precio),
                                  String.format("$%.2f", subtotal));
            }
        }
        
        documento.add(tabla);
        
        // Línea separadora antes del total
        Paragraph lineaTotal = new Paragraph("----------------------------------------", textoMonospace);
        lineaTotal.setAlignment(Element.ALIGN_CENTER);
        lineaTotal.setSpacingBefore(5f);
        lineaTotal.setSpacingAfter(5f);
        documento.add(lineaTotal);
        
        // Información de pago y total
        Paragraph infoPago = new Paragraph("Forma de pago: " + formaPago, textoDestacado);
        infoPago.setAlignment(Element.ALIGN_RIGHT);
        infoPago.setSpacingAfter(5f);
        documento.add(infoPago);
        
        Paragraph totalFinal = new Paragraph("TOTAL: $" + String.format("%.2f", total), 
                                           new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.RED));
        totalFinal.setAlignment(Element.ALIGN_RIGHT);
        totalFinal.setSpacingAfter(15f);
        documento.add(totalFinal);
    }
    
    private static void agregarHeaderTabla(PdfPTable tabla, String texto, Font fuente) {
        PdfPCell celda = new PdfPCell(new Phrase(texto, fuente));
        celda.setBackgroundColor(BaseColor.LIGHT_GRAY);
        celda.setPadding(5f);
        celda.setHorizontalAlignment(Element.ALIGN_CENTER);
        tabla.addCell(celda);
    }
    
    private static void agregarFilaProducto(PdfPTable tabla, String producto, String cantidad, 
                                          String precio, String subtotal) {
        // Producto
        PdfPCell celdaProducto = new PdfPCell(new Phrase(producto, textoFont));
        celdaProducto.setPadding(5f);
        tabla.addCell(celdaProducto);
        
        // Cantidad
        PdfPCell celdaCantidad = new PdfPCell(new Phrase(cantidad, textoFont));
        celdaCantidad.setPadding(5f);
        celdaCantidad.setHorizontalAlignment(Element.ALIGN_CENTER);
        tabla.addCell(celdaCantidad);
        
        // Precio
        PdfPCell celdaPrecio = new PdfPCell(new Phrase(precio, textoFont));
        celdaPrecio.setPadding(5f);
        celdaPrecio.setHorizontalAlignment(Element.ALIGN_RIGHT);
        tabla.addCell(celdaPrecio);
        
        // Subtotal
        PdfPCell celdaSubtotal = new PdfPCell(new Phrase(subtotal, textoFont));
        celdaSubtotal.setPadding(5f);
        celdaSubtotal.setHorizontalAlignment(Element.ALIGN_RIGHT);
        tabla.addCell(celdaSubtotal);
    }

    private static void agregarFooterTicket(Document documento) throws DocumentException {
        // Mensaje de agradecimiento
        Paragraph agradecimiento = new Paragraph("¡Gracias por su compra!", textoDestacado);
        agradecimiento.setAlignment(Element.ALIGN_CENTER);
        agradecimiento.setSpacingBefore(20f);
        agradecimiento.setSpacingAfter(10f);
        documento.add(agradecimiento);
        
        // Información de contacto
        Paragraph contacto = new Paragraph("Abarrotes La Soledad - Tu tienda de confianza\n" +
                                         "¡Esperamos verte pronto!", 
                                         new Font(Font.FontFamily.HELVETICA, 9, Font.ITALIC, BaseColor.GRAY));
        contacto.setAlignment(Element.ALIGN_CENTER);
        contacto.setSpacingBefore(10f);
        documento.add(contacto);
    }
}