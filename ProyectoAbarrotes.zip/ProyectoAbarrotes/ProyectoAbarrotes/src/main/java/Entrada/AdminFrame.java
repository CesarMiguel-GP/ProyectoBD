/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Entrada;

/**
 *

 */
import Conexion.ConexionMySQL;
import javax.swing.*;
import java.awt.*;
import java.sql.Connection;

public class AdminFrame extends JFrame {
    public AdminFrame() {
        setTitle("Panel de Administración - Abarrotes La Soledad 💚");
        setSize(400, 500); // Altura aumentada para ver todos los botones en columna
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel con layout de una columna y 4 filas
        JPanel panel = new JPanel(new GridLayout(4, 1, 15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        panel.setBackground(new Color(235, 255, 235));

        Font font = new Font("Segoe UI", Font.BOLD, 18);

         // Botón Productos
        JButton btnProductos = crearBoton("📦 Productos", font, new Color(144, 238, 144));
        btnProductos.addActionListener(e -> SwingUtilities.invokeLater(() -> {
            FrameProductos frame = new FrameProductos();
            frame.setLocationRelativeTo(null); // Centrar ventana
            frame.setVisible(true);
        }));
        panel.add(btnProductos);

        // Botón Usuarios
        JButton btnUsuarios = crearBoton("👥 Usuarios", font, new Color(255, 255, 153));
        btnUsuarios.addActionListener(e -> SwingUtilities.invokeLater(() -> {
            Registro frame = new Registro();
            frame.setLocationRelativeTo(null); // Centrar ventana
            frame.setVisible(true);
        }));
        panel.add(btnUsuarios);

        // Botón Agregar Proveedor
        JButton btnAgregarProveedor = crearBoton("🏷️ Agregar Proveedor", font, new Color(173, 216, 230));
        btnAgregarProveedor.addActionListener(e -> SwingUtilities.invokeLater(() -> {
            FormAgregarProveedor frame = new FormAgregarProveedor();
            frame.setLocationRelativeTo(null); // Centrar ventana
            frame.setVisible(true);
        }));
        panel.add(btnAgregarProveedor);

        // Botón Gestionar Productos
        JButton btnGestionarProductos = crearBoton("🛒 Gestionar Productos", font, new Color(255, 204, 204));
        btnGestionarProductos.addActionListener(e -> SwingUtilities.invokeLater(() -> {
            ClienteFrame frame = new ClienteFrame();
            frame.setLocationRelativeTo(null); // Centrar ventana
            frame.setVisible(true);
        }));
        panel.add(btnGestionarProductos);

        add(panel);
    }

    private JButton crearBoton(String texto, Font font, Color color) {
        JButton boton = new JButton(texto);
        boton.setFont(font);
        boton.setBackground(color);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2, true));
        return boton;
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Connection conn = ConexionMySQL.getConexion();
                if (conn != null && !conn.isClosed()) {
                    new AdminFrame().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "❌ No se pudo establecer la conexión con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "❌ Error inesperado: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}

