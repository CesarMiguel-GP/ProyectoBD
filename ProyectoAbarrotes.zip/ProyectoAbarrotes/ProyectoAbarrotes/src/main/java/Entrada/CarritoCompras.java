/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entrada;



import Conexion.ConexionMySQL;
import java.util.ArrayList;
import java.util.List;

public class CarritoCompras {
    private List<ProductoCompleto> productos;

    public CarritoCompras() {
        this.productos = new ArrayList<>();
    }

    public void agregarProducto(ProductoCompleto producto, int cantidad) {
        if (ConexionMySQL.hayStockSuficiente(producto.getIdProducto(), cantidad)) {
            producto.setCantidad(cantidad);
            productos.add(producto);
        } else {
            System.out.println("No hay suficiente stock para " + producto.getNombre());
        }
    }

    public void eliminarProducto(String idProducto) {
        productos.removeIf(p -> p.getIdProducto().equals(idProducto));
    }

    public void actualizarCantidad(String idProducto, int nuevaCantidad) {
        for (ProductoCompleto p : productos) {
            if (p.getIdProducto().equals(idProducto)) {
                if (ConexionMySQL.hayStockSuficiente(idProducto, nuevaCantidad)) {
                    p.setCantidad(nuevaCantidad);
                } else {
                    System.out.println("No hay suficiente stock");
                }
                break;
            }
        }
    }

    public double calcularTotal() {
        return productos.stream()
                .mapToDouble(p -> p.getPrecio() * p.getCantidad())
                .sum();
    }

    public List<ProductoCompleto> getProductos() {
        return new ArrayList<>(productos);
    }

    public void vaciarCarrito() {
        productos.clear();
    }
}
