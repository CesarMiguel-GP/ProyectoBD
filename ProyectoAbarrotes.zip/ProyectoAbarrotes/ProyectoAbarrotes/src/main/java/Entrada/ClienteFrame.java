/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Entrada;

/**
 
 */
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import Conexion.ConexionMySQL;
import Correo.GeneradorTicketPDF;
import Correo.EnvioCorreo;
import java.io.File;
    public class ClienteFrame extends JFrame {
    private JPanel panelProductos;
    private JTextField txtBuscar;
    private JLabel lblTotal;
    private double total = 0.0;
    private Map<String, Integer> carrito = new HashMap<>();

    public ClienteFrame() {
        setTitle("Abarrotes La Soledad - Catálogo de Productos");
        setSize(1100, 750);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Encabezado
        JPanel panelEncabezado = new JPanel(new BorderLayout());
        panelEncabezado.setBackground(new Color(240, 255, 240));
        panelEncabezado.setBorder(new EmptyBorder(15, 30, 15, 30));

        txtBuscar = new JTextField();
        txtBuscar.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        txtBuscar.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(144, 238, 144), 2), "Buscar producto"));
        txtBuscar.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                mostrarProductos(txtBuscar.getText());
            }
        });

        JButton btnCarrito = new JButton("🛒 Carrito");
        btnCarrito.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnCarrito.setFocusPainted(false);
        btnCarrito.setBackground(new Color(255, 255, 153));
        btnCarrito.setBorder(BorderFactory.createLineBorder(new Color(153, 153, 0), 2));
        btnCarrito.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnCarrito.addActionListener(e -> verCarrito());

        panelEncabezado.add(txtBuscar, BorderLayout.CENTER);
        panelEncabezado.add(btnCarrito, BorderLayout.EAST);

        // Panel de productos
        panelProductos = new JPanel(new GridLayout(0, 4, 15, 15));
        panelProductos.setBackground(new Color(255, 255, 240));
        JScrollPane scrollPane = new JScrollPane(panelProductos);
        scrollPane.setBorder(new EmptyBorder(15, 30, 15, 30));

        // Panel total inferior
        JPanel panelTotal = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelTotal.setBackground(new Color(240, 255, 240));
        lblTotal = new JLabel("Total: $0.00");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTotal.setForeground(new Color(0, 102, 51));
        panelTotal.add(lblTotal);

        add(panelEncabezado, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelTotal, BorderLayout.SOUTH);

        mostrarProductos("");
        setVisible(true);
    }

    private void mostrarProductos(String filtro) {
         panelProductos.removeAll();
        java.util.List<ProductoCompleto> productos = ConexionMySQL.obtenerProductos();
        for (ProductoCompleto p : productos) {
            if (filtro.isEmpty() || p.getNombre().toLowerCase().contains(filtro.toLowerCase())) {
                panelProductos.add(crearTarjetaProducto(p));
            }
        }
        panelProductos.revalidate();
        panelProductos.repaint();
    }

    private JPanel crearTarjetaProducto(ProductoCompleto p) {
       JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(255, 255, 255));
        panel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(144, 238, 144), 2, true),
            new EmptyBorder(10, 10, 10, 10))
        );

        JLabel lblImagen = new JLabel();
        lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
        lblImagen.setPreferredSize(new Dimension(150, 150));
        try {
            String ruta = "src/main/java" + p.getUrl();
            File archivo = new File(ruta);
            if (archivo.exists()) {
                ImageIcon icon = new ImageIcon(archivo.getAbsolutePath());
                Image img = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                lblImagen.setIcon(new ImageIcon(img));
            } else {
                lblImagen.setText("Sin imagen");
                lblImagen.setForeground(Color.GRAY);
            }
        } catch (Exception e) {
            lblImagen.setText("Sin imagen");
        }

        JLabel lblNombre = new JLabel(p.getNombre(), SwingConstants.CENTER);
        lblNombre.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblNombre.setForeground(new Color(0, 102, 51));

        JLabel lblPrecio = new JLabel("$" + String.format("%.2f", p.getPrecio()), SwingConstants.CENTER);
        lblPrecio.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblPrecio.setForeground(new Color(51, 51, 51));

        JButton btnAgregar = new JButton(p.getStock() > 0 ? "Agregar" : "Agotado");
        btnAgregar.setEnabled(p.getStock() > 0);
        btnAgregar.setBackground(p.getStock() > 0 ? new Color(144, 238, 144) : Color.LIGHT_GRAY);
        btnAgregar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btnAgregar.setFocusPainted(false);
        btnAgregar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnAgregar.setBorder(BorderFactory.createLineBorder(new Color(0, 153, 76)));
        btnAgregar.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(this, "¿Cuántas unidades deseas agregar de " + p.getNombre() + "?");
            if (input != null) {
                try {
                    int cantidad = Integer.parseInt(input);
                    if (cantidad <= 0) throw new NumberFormatException();
                    agregarAlCarrito(p, cantidad);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Cantidad inválida");
                }
            }
        });

        JPanel panelInfo = new JPanel(new GridLayout(0, 1));
        panelInfo.setBackground(Color.white);
        panelInfo.add(lblNombre);
        panelInfo.add(lblPrecio);
        panelInfo.add(btnAgregar);

        panel.add(lblImagen, BorderLayout.CENTER);
        panel.add(panelInfo, BorderLayout.SOUTH);
        return panel;
    }
    
    private void agregarAlCarrito(ProductoCompleto producto, int cantidad) {
        int cantidadActual = carrito.getOrDefault(producto.getIdProducto(), 0);
        int nuevaCantidad = cantidadActual + cantidad;
        if (ConexionMySQL.hayStockSuficiente(producto.getIdProducto(), nuevaCantidad)) {
            carrito.put(producto.getIdProducto(), nuevaCantidad);
            total += producto.getPrecio() * cantidad;
            lblTotal.setText("Total: $" + String.format("%.2f", total));
            JOptionPane.showMessageDialog(this, producto.getNombre() + " x" + cantidad + " agregado(s) al carrito.");
        } else {
            JOptionPane.showMessageDialog(this, "Stock insuficiente para " + producto.getNombre());
        }
        
    }



    private void verCarrito() {
        if (carrito.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tu carrito está vacío.");
            return;
        }

        JDialog dialog = new JDialog(this, "Carrito de Compras", true);
        dialog.setSize(700, 450);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        String[] columnas = {"Producto", "Cantidad", "Precio Unitario", "Subtotal"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            public boolean isCellEditable(int row, int col) {
                return col == 1;
            }

            public Class<?> getColumnClass(int col) {
                return (col == 1) ? Integer.class : (col == 2 || col == 3) ? Double.class : String.class;
            }
        };

        for (String id : carrito.keySet()) {
            ProductoCompleto p = ConexionMySQL.buscarProductoPorID(id);
            int cantidad = carrito.get(id);
            Object[] fila = {p.getNombre(), cantidad, p.getPrecio(), p.getPrecio() * cantidad};
            modelo.addRow(fila);
        }

        JTable tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        dialog.add(scroll, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JLabel lblTotalDialog = new JLabel("Total: $" + String.format("%.2f", total));
        lblTotalDialog.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar Seleccionado");
        JButton btnFinalizar = new JButton("Finalizar Compra");
        JButton btnCerrar = new JButton("Cerrar");

        btnActualizar.addActionListener(e -> {
            double nuevoTotal = 0.0;
            boolean todoOK = true;

            for (int i = 0; i < modelo.getRowCount(); i++) {
                String nombre = (String) modelo.getValueAt(i, 0);
                int cantidad = (Integer) modelo.getValueAt(i, 1);
                ProductoCompleto p = ConexionMySQL.buscarProductoPorNombre(nombre);
                if (cantidad <= 0 || cantidad > ConexionMySQL.obtenerStock(p.getIdProducto())) {
                    JOptionPane.showMessageDialog(dialog, "Cantidad inválida para " + nombre);
                    todoOK = false;
                    break;
                }
                carrito.put(p.getIdProducto(), cantidad);
                modelo.setValueAt(p.getPrecio() * cantidad, i, 3);
                nuevoTotal += p.getPrecio() * cantidad;
            }

            if (todoOK) {
                total = nuevoTotal;
                lblTotalDialog.setText("Total: $" + String.format("%.2f", total));
                lblTotal.setText("Total: $" + String.format("%.2f", total));
                JOptionPane.showMessageDialog(dialog, "Carrito actualizado.");
            }
        });

        btnEliminar.addActionListener(e -> {
            int fila = tabla.getSelectedRow();
            if (fila >= 0) {
                String nombre = (String) modelo.getValueAt(fila, 0);
                ProductoCompleto p = ConexionMySQL.buscarProductoPorNombre(nombre);
                carrito.remove(p.getIdProducto());
                modelo.removeRow(fila);
                recalcularTotal(modelo, lblTotalDialog);
            }
        });

 btnFinalizar.addActionListener(e -> {
    String[] opcionesPago = {"Efectivo", "Tarjeta", "Transferencia"};
    String formaPago = (String) JOptionPane.showInputDialog(dialog, 
        "Selecciona tu forma de pago:", 
        "Forma de Pago", 
        JOptionPane.QUESTION_MESSAGE, 
        null, 
        opcionesPago, 
        opcionesPago[0]);

    if (formaPago != null) {
        // Crear panel de ticket
        JDialog ticketDialog = new JDialog(this, "Ticket de Compra", true);
        ticketDialog.setSize(500, 600);
        ticketDialog.setLocationRelativeTo(this);
        ticketDialog.setLayout(new BorderLayout());

        JTextArea areaTicket = new JTextArea();
        areaTicket.setFont(new Font("Monospaced", Font.PLAIN, 14));
        areaTicket.setEditable(false);

        StringBuilder ticket = new StringBuilder();
        ticket.append("🛒 Abarrotes La Soledad\n");
        ticket.append("📅 Fecha: ").append(new java.util.Date()).append("\n\n");
        ticket.append(String.format("%-20s%-10s%-10s\n", "Producto", "Cant", "Subtot"));
        ticket.append("----------------------------------------\n");

        for (String id : carrito.keySet()) {
            ProductoCompleto p = ConexionMySQL.buscarProductoPorID(id);
            int cantidad = carrito.get(id);
            double subtotal = cantidad * p.getPrecio();
            ticket.append(String.format("%-20s%-10d$%.2f\n", p.getNombre(), cantidad, subtotal));
        }

        ticket.append("\nForma de pago: ").append(formaPago).append("\n");
        ticket.append("TOTAL: $").append(String.format("%.2f", total)).append("\n");

        areaTicket.setText(ticket.toString());

        JScrollPane scr = new JScrollPane(areaTicket);
        ticketDialog.add(scr, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        JButton btnImprimir = new JButton("🖨 Imprimir");
        JButton btnCorreo = new JButton("📧 Enviar por correo");
        JButton btnCerrarTicket = new JButton("Cerrar");

        panelBotones.add(btnImprimir);
        panelBotones.add(btnCorreo);
        panelBotones.add(btnCerrarTicket);

        ticketDialog.add(panelBotones, BorderLayout.SOUTH);

        // Acción imprimir (simulada)
        btnImprimir.addActionListener(ev -> {
            JOptionPane.showMessageDialog(ticketDialog, "Enviando a la impresora...");
        });

        // Acción enviar correo
        btnCorreo.addActionListener(ev -> {
        String correo = JOptionPane.showInputDialog(ticketDialog, "Ingresa tu correo:");
        if (correo != null && !correo.trim().isEmpty()) {
            // Validar formato de correo básico
            if (!correo.contains("@") || !correo.contains(".")) {
                JOptionPane.showMessageDialog(ticketDialog, "Por favor ingresa un correo válido");
                return;
            }

            // Generar nombre único para el archivo PDF
            String nombreArchivo = "ticket_" + System.currentTimeMillis() + ".pdf";
            String rutaPDF = System.getProperty("java.io.tmpdir") + File.separator + nombreArchivo;

            // Mostrar mensaje de procesamiento
          JDialog procesandoDialog = new JDialog(ticketDialog, "Procesando...", true);
             JLabel lblProcesando = new JLabel("Generando PDF y enviando correo...", SwingConstants.CENTER);
                  procesandoDialog.add(lblProcesando);
                 procesandoDialog.setSize(300, 100);

// ✅ Aquí centras la ventana "Procesando..." respecto al ticket
procesandoDialog.setLocationRelativeTo(ticketDialog);

            // Ejecutar en hilo separado para no bloquear la UI
            SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
                @Override
                protected Boolean doInBackground() throws Exception {
                    // Generar PDF del ticket
                    boolean pdfGenerado = GeneradorTicketPDF.generarTicketCompraPDF(
                        carrito, total, formaPago, rutaPDF, correo
                    );

                    if (!pdfGenerado) {
                        return false;
                    }

                    // Enviar por correo
                    return EnvioCorreo.enviarTicketPorCorreo(correo, rutaPDF);
                }

                @Override
                protected void done() {
                    procesandoDialog.dispose();
                    try {
                        boolean exitoso = get();
                        if (exitoso) {
                            JOptionPane.showMessageDialog(ticketDialog, 
                                "Ticket enviado exitosamente a " + correo);
                        } else {
                            JOptionPane.showMessageDialog(ticketDialog, 
                                "Error al enviar el ticket. Inténtalo de nuevo.");
                        }

                        // Limpiar archivo temporal
                        try {
                            new File(rutaPDF).delete();
                        } catch (Exception e) {
                            // Ignorar errores de limpieza
                        }

                    } catch (Exception e) {
                        procesandoDialog.dispose();
                        JOptionPane.showMessageDialog(ticketDialog, 
                            "Error al procesar la solicitud: " + e.getMessage());
                    }
                }
            };

            // Mostrar dialog de procesamiento y ejecutar worker
            worker.execute();
            procesandoDialog.setVisible(true);
        }
    });

        // Acción cerrar ticket y finalizar compra
        btnCerrarTicket.addActionListener(ev -> {
            // Descontar stock de cada producto
            for (String id : carrito.keySet()) {
                int cantidad = carrito.get(id);
                ConexionMySQL.descontarStock(id, cantidad);
            }

            carrito.clear();
            total = 0.0;
            lblTotal.setText("Total: $0.00");
            dialog.dispose(); // cerrar carrito
            ticketDialog.dispose(); // cerrar ticket

            mostrarProductos(""); // refrescar productos
        });

        ticketDialog.setVisible(true);
    }
});

        btnCerrar.addActionListener(e -> dialog.dispose());

        panelInferior.add(lblTotalDialog);
        panelInferior.add(btnActualizar);
        panelInferior.add(btnEliminar);
        panelInferior.add(btnFinalizar);
        panelInferior.add(btnCerrar);

        dialog.add(panelInferior, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void recalcularTotal(DefaultTableModel modelo, JLabel lblTotalDialog) {
        double nuevoTotal = 0.0;
        for (int i = 0; i < modelo.getRowCount(); i++) {
            nuevoTotal += (Double) modelo.getValueAt(i, 3);
        }
        total = nuevoTotal;
        lblTotal.setText("Total: $" + String.format("%.2f", total));
        lblTotalDialog.setText("Total: $" + String.format("%.2f", total));
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> {
            try {
                if (ConexionMySQL.getConexion() != null) {
                    new ClienteFrame();
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo establecer conexión con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al iniciar aplicación: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
