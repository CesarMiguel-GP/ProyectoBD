/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Entrada;

/**
 
 */
import javax.swing.*;
import java.awt.*;
import Conexion.ConexionMySQL;
public class FormAgregarProveedor extends javax.swing.JFrame {
public FormAgregarProveedor() {
        setTitle("Agregar Proveedor");
        setSize(350, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(255, 255, 240));

        Font fuente = new Font("Segoe UI", Font.PLAIN, 15);

        JTextField txtIdProveedor = new JTextField();
        JTextField txtNombreProveedor = new JTextField();

        panel.add(new JLabel("ID Proveedor:")).setFont(fuente); panel.add(txtIdProveedor);
        panel.add(new JLabel("Nombre:")).setFont(fuente); panel.add(txtNombreProveedor);

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBackground(new Color(255, 255, 153));
        btnAgregar.setFont(fuente);
        btnAgregar.addActionListener(e -> {
            ConexionMySQL.insertarProveedor(txtIdProveedor.getText(), txtNombreProveedor.getText());
            JOptionPane.showMessageDialog(null, "Proveedor agregado correctamente.");
        });

        panel.add(new JLabel(""));
        panel.add(btnAgregar);
        add(panel);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> {
            try {
                if (ConexionMySQL.getConexion() != null) {
                    new ClienteFrame();
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo establecer conexión con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al iniciar aplicación: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
