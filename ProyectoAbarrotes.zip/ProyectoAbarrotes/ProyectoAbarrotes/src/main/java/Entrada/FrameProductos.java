/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Entrada;

/**
 
 */
import Conexion.ConexionMySQL;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
public class FrameProductos extends javax.swing.JFrame {
private JTable tablaProductos;
    private JTextField txtBuscar, txtNombre, txtPrecio, txtUrl, txtStock, txtProveedor;
    private DefaultTableModel modelo;
    private JComboBox<String> comboTipo;
    private int idSeleccionado = -1; // ID oculto para actualizar/eliminar

    public FrameProductos() {
        setTitle("Gestión de Productos");
        setSize(1100, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        
           // Panel superior con botón regresar
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnRegresar = new JButton("↩ Regresar");
        btnRegresar.addActionListener(e -> dispose());
        panelSuperior.add(btnRegresar);
        add(panelSuperior, BorderLayout.NORTH);
        
        JPanel panelIzquierdo = new JPanel(new GridLayout(8, 2, 5, 5));
        panelIzquierdo.setPreferredSize(new Dimension(400, 0));
        panelIzquierdo.setBorder(BorderFactory.createTitledBorder("Formulario de Producto"));
        panelIzquierdo.setBackground(new Color(235, 255, 235));

        txtNombre = new JTextField();
        comboTipo = new JComboBox<>(new String[]{
            "Abarrotes Básicos", "Pan y Galletas", "Bebidas",
            "Dulcería y Snacks", "Limpieza e Higiene", "Productos Perecederos",
            "Bebés y Maternidad", "Mascotas", "Otros / Farmacia básica"
        });
        txtPrecio = new JTextField();
        txtUrl = new JTextField();
        txtStock = new JTextField();
        txtProveedor = new JTextField();

        panelIzquierdo.add(new JLabel("Nombre:")); panelIzquierdo.add(txtNombre);
        panelIzquierdo.add(new JLabel("Tipo:")); panelIzquierdo.add(comboTipo);
        panelIzquierdo.add(new JLabel("Precio:")); panelIzquierdo.add(txtPrecio);
        panelIzquierdo.add(new JLabel("URL Imagen:")); panelIzquierdo.add(txtUrl);
        panelIzquierdo.add(new JLabel("Stock:")); panelIzquierdo.add(txtStock);
        panelIzquierdo.add(new JLabel("ID Proveedor:")); panelIzquierdo.add(txtProveedor);

        JButton btnAgregar = new JButton("Agregar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");

        panelIzquierdo.add(btnAgregar); panelIzquierdo.add(btnActualizar);
        panelIzquierdo.add(btnEliminar); panelIzquierdo.add(btnLimpiar);

        add(panelIzquierdo, BorderLayout.WEST);

        JPanel panelDerecho = new JPanel(new BorderLayout());
        txtBuscar = new JTextField();
        txtBuscar.setToolTipText("Buscar por nombre...");
        panelDerecho.add(txtBuscar, BorderLayout.NORTH);

        modelo = new DefaultTableModel(new String[]{
            "ID", "Nombre", "Tipo", "Precio", "URL", "Stock", "Proveedor"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaProductos = new JTable(modelo);
        tablaProductos.getColumnModel().getColumn(0).setMinWidth(0);
        tablaProductos.getColumnModel().getColumn(0).setMaxWidth(0);

        JScrollPane scroll = new JScrollPane(tablaProductos);
        panelDerecho.add(scroll, BorderLayout.CENTER);
        add(panelDerecho, BorderLayout.CENTER);

        cargarProductos("");

        tablaProductos.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = tablaProductos.getSelectedRow();
                if (fila >= 0) {
                    idSeleccionado = Integer.parseInt(modelo.getValueAt(fila, 0).toString());
                    txtNombre.setText(modelo.getValueAt(fila, 1).toString());
                    comboTipo.setSelectedItem(modelo.getValueAt(fila, 2).toString());
                    txtPrecio.setText(modelo.getValueAt(fila, 3).toString());
                    txtUrl.setText(modelo.getValueAt(fila, 4).toString());
                    txtStock.setText(modelo.getValueAt(fila, 5).toString());
                    txtProveedor.setText(modelo.getValueAt(fila, 6).toString());
                }
            }
        });

        txtBuscar.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                cargarProductos(txtBuscar.getText());
            }
        });

        btnLimpiar.addActionListener(e -> limpiarCampos());

    btnAgregar.addActionListener(e -> {
    int confirm = JOptionPane.showConfirmDialog(this, "¿Deseas agregar este producto?", "Confirmar Agregado", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) return; // ← si elige "No", se cancela todo

    try (Connection conn = ConexionMySQL.getConexion()) {
        String sql = "INSERT INTO productos (nombre, tipo, precio, url, stock, id_proveedor) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, txtNombre.getText());
        ps.setString(2, comboTipo.getSelectedItem().toString());
        ps.setDouble(3, Double.parseDouble(txtPrecio.getText()));
        ps.setString(4, txtUrl.getText());
        ps.setInt(5, Integer.parseInt(txtStock.getText()));
        ps.setInt(6, Integer.parseInt(txtProveedor.getText()));
        ps.executeUpdate();
        cargarProductos("");
        limpiarCampos();
        JOptionPane.showMessageDialog(this, "Producto agregado correctamente.");
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al agregar: " + ex.getMessage());
    }
});

   btnActualizar.addActionListener(e -> {
    if (idSeleccionado == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona un producto primero.");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(this, "¿Deseas actualizar este producto?", "Confirmar Actualización", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) return;

    try (Connection conn = ConexionMySQL.getConexion()) {
        String sql = "UPDATE productos SET nombre=?, tipo=?, precio=?, url=?, stock=?, id_proveedor=? WHERE id_producto=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, txtNombre.getText());
        ps.setString(2, comboTipo.getSelectedItem().toString());
        ps.setDouble(3, Double.parseDouble(txtPrecio.getText()));
        ps.setString(4, txtUrl.getText());
        ps.setInt(5, Integer.parseInt(txtStock.getText()));
        ps.setInt(6, Integer.parseInt(txtProveedor.getText()));
        ps.setInt(7, idSeleccionado);
        ps.executeUpdate();
        cargarProductos("");
        limpiarCampos();
        JOptionPane.showMessageDialog(this, "Producto actualizado correctamente.");
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al actualizar: " + ex.getMessage());
    }
});
   
       btnEliminar.addActionListener(e -> {
    if (idSeleccionado == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona un producto primero.");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(this, "¿Deseas eliminar este producto?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) return;

    try (Connection conn = ConexionMySQL.getConexion()) {
        String sql = "DELETE FROM productos WHERE id_producto=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, idSeleccionado);
        ps.executeUpdate();
        cargarProductos("");
        limpiarCampos();
        JOptionPane.showMessageDialog(this, "Producto eliminado correctamente.");
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al eliminar: " + ex.getMessage());
    }
});
    }

    private void cargarProductos(String filtro) {
        modelo.setRowCount(0);
        try (Connection conn = ConexionMySQL.getConexion();
             Statement st = conn.createStatement()) {
            String query = "SELECT * FROM productos";
            if (!filtro.isEmpty()) {
                query += " WHERE nombre LIKE '%" + filtro + "%'";
            }
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                Vector<Object> fila = new Vector<>();
                fila.add(rs.getInt("id_producto"));
                fila.add(rs.getString("nombre"));
                fila.add(rs.getString("tipo"));
                fila.add(rs.getDouble("precio"));
                fila.add(rs.getString("url"));
                fila.add(rs.getInt("stock"));
                fila.add(rs.getInt("id_proveedor"));
                modelo.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar productos: " + e.getMessage());
        }
    }

    private void limpiarCampos() {
        idSeleccionado = -1;
        txtNombre.setText("");
        comboTipo.setSelectedIndex(0);
        txtPrecio.setText("");
        txtUrl.setText("");
        txtStock.setText("");
        txtProveedor.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> {
            if (ConexionMySQL.getConexion() != null) {
                new FrameProductos().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo conectar a la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
