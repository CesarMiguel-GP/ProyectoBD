/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entrada;

/**
 */
public class ProductoCompleto {
    private String idProducto;      // Antes: id
    private String nombre;
    private String tipo;
    private double precio;
    private String url;
    private int stock;
    private int cantidad;           // No está en la base, se usa en el carrito
    private String idProveedor;     // NUEVO: se agrega para coincidir con la tabla

    public ProductoCompleto(String idProducto, String nombre, String tipo,
                            double precio, String url, int stock, String idProveedor) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.tipo = tipo;
        this.precio = precio;
        this.url = url;
        this.stock = stock;
        this.idProveedor = idProveedor;
        this.cantidad = 0; // Para el carrito
    }

    // Getters y Setters
    public String getIdProducto() { return idProducto; }
    public void setIdProducto(String idProducto) { this.idProducto = idProducto; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public String getIdProveedor() { return idProveedor; }
    public void setIdProveedor(String idProveedor) { this.idProveedor = idProveedor; }
}
