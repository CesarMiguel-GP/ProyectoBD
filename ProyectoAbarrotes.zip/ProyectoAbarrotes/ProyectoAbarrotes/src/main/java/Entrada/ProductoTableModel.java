/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entrada;

/**
 */
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class ProductoTableModel extends AbstractTableModel {
    private List<ProductoCompleto> productos;
    private final String[] columnNames = {"ID", "Nombre", "Tipo", "Precio", "Stock"};

    public ProductoTableModel() {
        this.productos = new ArrayList<>();
    }

    public void setProductos(List<ProductoCompleto> productos) {
        this.productos = productos;
        fireTableDataChanged(); // Para que la tabla se refresque
    }

    public ProductoCompleto getProductoAt(int rowIndex) {
        return productos.get(rowIndex);
    }

    @Override
    public int getRowCount() {
        return productos.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        ProductoCompleto producto = productos.get(rowIndex);
        switch (columnIndex) {
            case 0: return producto.getIdProducto();   // Cambié de getId() a getIdProducto()
            case 1: return producto.getNombre();
            case 2: return producto.getTipo();
            case 3: return String.format("$%.2f", producto.getPrecio());
            case 4: return producto.getStock();
            default: return null;
        }
    }
}

